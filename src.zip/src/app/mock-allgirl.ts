import { Girl } from './girl';

export const ALLGIRL: Girl[] = [
  { id: 1, name: 'น้องส้ม' },
  { id: 2, name: 'น้องแบม1' },
  { id: 3, name: 'น้องแบม2' },
  { id: 4, name: 'พี่สมหญิง' },
  { id: 5, name: 'น้องแนน' },
  { id: 6, name: 'น้องกวาง' },
  { id: 7, name: 'น้องเกด' },
  { id: 8, name: 'น้องแป้ง' },
  { id: 9, name: 'เนย' },
  { id: 10, name: 'เมย์' }
];