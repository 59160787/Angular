import { Component, OnInit } from '@angular/core';
import { Girl } from '../girl';
import { ALLGIRL } from '../mock-allgirl';

@Component({
  selector: 'app-girl',
  templateUrl: './girl.component.html',
  styleUrls: ['./girl.component.css']
})
export class GirlComponent implements OnInit {

  allgirl = ALLGIRL;
  selectedGirl?: Girl;

  constructor() { }

  ngOnInit(): void {
  }

  onSelect(girl: Girl): void {
    this.selectedGirl = girl;
  }
}
