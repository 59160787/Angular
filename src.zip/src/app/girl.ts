export interface Girl {
    id: number;
    name: string;
  }